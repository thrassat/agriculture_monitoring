#include <SPI.h>
#include <WiFiNINA.h>

void connect_wifi(char * ssid,char * pwd) ; 