#include <ArduinoHttpClient.h>
#include <SPI.h>

void send_plain_post (WiFiClient wifiClient, char * IPServer, uint16_t port, String URL, String sensorId, String timestamp, String value) {
 // todo try to remove "String" 
 // IPServer peut-être de type : char *, String, IPAddress
  HttpClient http = HttpClient(wifiClient, IPServer, port);

  // Args : URLPath (char * ou String) , ContentType (char * ou String), Body (char *, String, byte[])
  // 2107 ça c'est ok l'appli attend ça NON APPLI ATTEND /receiver/ardID/co2
  http.post(URL+"/receiver/"+sensorId,"text/plain",timestamp+" "+value);
  int statusCode = http.responseStatusCode();
  String response = http.responseBody();
  Serial.print("[HTTP] Status code: ");
  Serial.println(statusCode);
  Serial.print("[HTTP] Response: ");
  Serial.println(response);
  http.stop();
}


void send_setup_informations (WiFiClient wifiClient, char * IPServer, uint16_t port, String URL, String groupId, String groupName, String timezone, String types[], uint8_t nbSensors) {
  // use json lib pour passer les types ? 
  // ou bien envoyer du plain type id-name-type1-type2.... 
  // two way to get type array length : 
  // * passer nb sensor comme argument : présent dans le code arduino (3) 
  // * sizeof(types) : en bytes, multiple de 12 d'après le test (sizeof(types[i])) toujours 12
  // Ici sizeof(types) retourne directement la bonne length 
  Serial.println(sizeof(types)); 
  
  String typeString = ""; 
//  Serial.println(typeSize) ; 
  for(int i=0; i<nbSensors;i++){
    Serial.println(types[i]); 
    typeString = typeString+"-"+types[i]; 
  }
  Serial.println(typeString); 
  // String JSONData = "{\"groupid\":\""+groupId+"\",\"groupName\":\""+groupName+"\",\"types\":\""+types+"\"}";
  // Issue with type : need to use JSON library or alternatives like sending plain text : 
  // todo : sensorgroup name = user input ? Ajouté depuis l'application? Si envoyé ici exclure le tiret possible dans le name 
 // old 2107 String plainText = groupId+"-"+groupName+"-"+timezone+typeString; 
  String plainText = groupId+typeString ; 
  Serial.println(plainText) ; 
  //2107 todo tester et supprimer uselessdata 
  HttpClient http = HttpClient(wifiClient, IPServer, port); 
  //http.post(URL+"/ardSetup",)
  http.post(URL+"/ardSetup","text/plain", plainText); 
  // old 2107 http.post(URL+"/groupsetup","text/plain", plainText); 
    int statusCode = http.responseStatusCode();
  String response = http.responseBody();
  Serial.print("[HTTP] Status code: ");
  Serial.println(statusCode);
  Serial.print("[HTTP] Response: ");
  Serial.println(response);
  http.stop(); 
} 
